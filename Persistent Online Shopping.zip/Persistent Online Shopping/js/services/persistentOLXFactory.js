angular.module('persistentOLXApp')
    .factory('persistentOLXFactory', function ($http, $q) {
        return {
            itemDetails: {},
            selectedItem:'',
            cartContent:[],
            address:{},
            fetchPhonesList: function (url) {
                if(!url){
                    url = 'phones'
                }
                var deferred = $q.defer();
                $http.get('./data/' + url + '.json').success(function (data, status, headers, config) {
                    deferred.resolve(data, status, headers, config);
                }).error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config)
                });
                return deferred.promise;
            },
            fetchSearchItemDetails: function () {
                var deferred = $q.defer();
                var self = this;
                if(!self.selectedItem){
                    self.selectedItem = 'motorola-xoom';
                }
                $http.get('./data/' + self.selectedItem + '.json').success(function (data, status, headers, config) {
                    self.itemDetails = data;
                    deferred.resolve(data, status, headers, config);
                }).error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config)
                });
                return deferred.promise;
            },
            getUserDetails: function () {
                var deferred = $q.defer();
                $http.get('./data/users.json').success(function (data, status, headers, config) {
                    deferred.resolve(data, status, headers, config);
                }).error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config)
                });
                return deferred.promise;
            }
        }
    });