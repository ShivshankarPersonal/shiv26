angular.module("persistentOLXApp")
    .controller("cartController", function ($scope, $state, persistentOLXFactory, $rootScope, $location) {
        if (!sessionStorage.getItem("loginId")) {
            $state.go("login");
        }
        $rootScope.searchBox = true;
        $scope.breadCrumbs = [ {
            name: 'Home',
            state: 'productCatalogue'
        }, {
            name: 'Product Details',
            state: 'productDetails'
        }, {
            name: 'Cart Details',
            state: 'cart'
        }];
        renderCartTable();

        function renderCartTable() {
            $scope.showCheckOutButton = true;
            $rootScope.cartCount = persistentOLXFactory.cartContent.length;
            var length = persistentOLXFactory.cartContent.length;
            $scope.totalPrice = 0;
            $scope.totalItemCount = persistentOLXFactory.cartContent.length;
            persistentOLXFactory.totalCartItemCount = persistentOLXFactory.cartContent.length;
            for (var j = 0; j < length; j++) {
                $scope.totalPrice += persistentOLXFactory.cartContent[j].price;
            }
            persistentOLXFactory.totalPrice = $scope.totalPrice;
            $scope.cartItems = persistentOLXFactory.cartContent;
            if ($scope.cartItems.length === 0) {
                $scope.totalPrice = 0;
                $scope.totalItemCount = 0;
                $scope.showCheckOutButton = false;
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            }
        }
        $scope.checkOut = function(){
            $state.go('checkOut')
        };
        $scope.removeItemFromCart = function (rowIndex) {
            $scope.cartItems[rowIndex].id
            for (var i = 0; i < persistentOLXFactory.cartContent.length; i++) {
                if ($scope.cartItems[rowIndex].id === persistentOLXFactory.cartContent[i]) {
                    persistentOLXFactory.cartContent.splice(i, 1)
                }
            }
            $scope.cartItems.splice(rowIndex, 1);
            renderCartTable();
        };
    });