angular.module("persistentOLXApp")
    .controller("thankYouController", function ($scope, $state, persistentOLXFactory, $rootScope) {
        if (!sessionStorage.getItem("loginId")) {
            $state.go("login");
        }
        $rootScope.searchBox = true;
        $scope.breadCrumbs = [{
            name:'Home',
            state:'productCatalogue'
        }, {
            name:'Product Details',
            state:'productDetails'
        }, {
            name:'Cart Details',
            state:'cart'
        }, {
            name:'Check Out',
            state:'checkOut'
        }, {
            name:'Purchase Summary',
            state:'purchaseSummary'
        }, {
            name:'Thank You',
            state:'thankYou'
        }];

        if (!sessionStorage.getItem("loginId")) {
            $state.go("login");
        }
        //$rootScope.searchBox = false;
        $rootScope.cartCount = null;
        //persistentOLXFactory.address = {};
        persistentOLXFactory.cartContent = [];
        //sessionStorage.removeItem('loginId');
    });