angular.module('persistentOLXApp')
    .controller('productDetailsController', function ($scope, $state, persistentOLXFactory, $rootScope) {
        if (!sessionStorage.getItem("loginId")) {
            $state.go("login");
        }
        $rootScope.searchBox = true;
        $scope.breadCrumbs = [{
            name: 'Home',
            state: 'productCatalogue'
        }, {
            name: 'Product Details',
            state: 'productDetails'
        }];
        persistentOLXFactory.fetchSearchItemDetails().then(function (data) {
            $scope.data = data;
            bindDataToView()
        }, function (data) {
            console.error("Unabel to Fetch items Details"+data)
        });
        function bindDataToView() {
            $scope.obj = $scope.data;
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        }

        $scope.addToCart = function () {
            persistentOLXFactory.fetchSearchItemDetails().then(function (data) {
                var obj = {};
                obj.name = data.name;
                obj.price = data.price;
                persistentOLXFactory.cartContent.push(angular.copy(obj));
                $state.go('cart');
            }, function (data) {
                console.error("Failed to Fetch Item Details" + data);
            });

        };
        $scope.$on('onItemClickInSearchBox', function () {
            persistentOLXFactory.fetchSearchItemDetails().then(function (data) {
                $scope.data = data;
                bindDataToView()
            }, function (data) {
                console.error("Unabel to Fetch items Details"+data);
            });
        })
    });