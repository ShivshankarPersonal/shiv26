angular.module("persistentOLXApp")
    .controller("purchaseSummaryController", function ($scope, $state, persistentOLXFactory, $rootScope) {
        if (!sessionStorage.getItem("loginId")) {
            $state.go("login");
        }
        $rootScope.searchBox = true;
        $scope.breadCrumbs = [{
            name:'Home',
            state:'productCatalogue'
        }, {
            name:'Product Details',
            state:'productDetails'
        }, {
            name:'Cart Details',
            state:'cart'
        }, {
            name:'Check Out',
            state:'checkOut'
        }, {
            name:'Purchase Summary',
            state:'purchaseSummary'
        }];
        $scope.address = persistentOLXFactory.address;
        $scope.totalItemCount = persistentOLXFactory.totalCartItemCount;
        $scope.totalPrice = persistentOLXFactory.totalPrice;
        $scope.placeOrder = function () {
            var length = persistentOLXFactory.cartContent.length;
            persistentOLXFactory.cartContent.splice(0, length);
            $state.go('thankYou')
        }
    });