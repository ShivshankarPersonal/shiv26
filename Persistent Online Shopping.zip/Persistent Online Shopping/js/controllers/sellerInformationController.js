angular.module('persistentOLXApp')
    .controller('sellerInformationController', function ($scope, persistentOLXFactory, $state, $location) {
        if (!sessionStorage.getItem("loginId")) {
            $state.go("login");
        }
        var data = persistentOLXFactory.itemDetails;
        $scope.sellerInfo = data.sellerInfo;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    });