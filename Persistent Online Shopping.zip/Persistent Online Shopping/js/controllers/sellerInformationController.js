angular.module('persistentOLXApp')
    .controller('sellerInformationController', function ($scope, persistentOLXFactory, $state, $location) {
        if (!sessionStorage.getItem("loginId")) {
            $state.go("login");
        }
        $scope.breadCrumbs = [{
            name: 'Home',
            state: 'productCatalogue'
        }, {
            name: 'Seller Information',
            state: 'sellerInformation'
        }];
        var data = persistentOLXFactory.itemDetails;
        $scope.sellerInfo = data.sellerInfo;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    });