angular.module('searchBox', [])
    .directive('searchBox', function (persistentOLXFactory, $state, $rootScope) {
        return {
            restrict: 'E',
            templateUrl: 'templates/searchBox.html',
            link: function ($scope, element, attr) {
                persistentOLXFactory.fetchPhonesList(attr.dropdownlisturl).then(function (data) {
                    $scope.phones = data;
                }, function (data, status) {
                    console.error('Error in fetching phones list' + data + status)
                });
                $scope.onSearchItemClick = function (phoneID, name) {
                    $scope.query = name;
                    persistentOLXFactory.selectedItem = phoneID;
                    persistentOLXFactory.fetchSearchItemDetails().then(function (data) {}, function (data) {
                        console.log("Error occured while fetching product details"+data)
                    });
                    $state.go('productDetails');
                    $scope.$broadcast("onItemClickInSearchBox",{});
                    $scope.searchBoxDropDownList = false;
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                };
                $scope.onSearchFieldFocus = function () {
                    $scope.searchBoxDropDownList = true;
                };
                $scope.onClearIconClick = function () {
                    $scope.query = '';
                    $scope.searchBoxDropDownList = true;
                };
                $scope.onSearchBoxHover = function(){
                    $scope.searchBoxDropDownList = true;
                };
                $scope.onSearchBoxLeave = function(){
                    $scope.searchBoxDropDownList = false;
                };

                $scope.config = {
                    autoHideScrollbar: false,
                    theme: '3d-thick',
                    advanced:{
                        updateOnContentResize: true
                    },
                    scrollInertia: 0
                }
            }
        }
    });