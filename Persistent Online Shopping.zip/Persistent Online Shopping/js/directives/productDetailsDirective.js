angular.module('productDetails', [])
    .directive('productDetails', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/productDetailsPartials.html',
            link: function ($scope) {
                $scope.productDescriptionOpenStatus = true;
                $scope.productSpecificationOpenStatus = false;
            }
        }
    });