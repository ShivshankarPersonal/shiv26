angular.module('productSpecifications', [])
    .directive('productSpecifications', function (persistentOLXFactory, $state) {
        return {
            restrict:'E',
            templateUrl:'templates/productSpecificationsPartials.html',
            controller:'productDetailsController'
        }
    });